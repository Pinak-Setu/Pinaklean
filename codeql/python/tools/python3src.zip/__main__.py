import semmle.populator

if __name__ == "__main__":
    semmle.populator.main()
